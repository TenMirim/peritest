from easygame import *
import random

# Constants.
width, height = 800, 600
track_width = 20
hot_distance = 100
hot_radius = 30
speed = 100

class Projector:
    def __init__(self, origin, near, far):
        self._origin = origin
        self._near = near
        self._far = far

    def vec(self, u):
        (ux, uy) = u
        ux = self.size(ux, uy)
        return (ux + self._origin[0], uy + self._origin[1])

    def size(self, s, y):
        return s * (self._far - y) / (self._far - self._near)

class Fruits:
    def __init__(self, image_paths, choreography_path):
        self._fruits = []
        self._index = 0
        self._mistakes = 0
        self._images = []
        for path in image_paths:
            self._images.append(load_image(path))
        with open(choreography_path) as chf:
            self._choreography = []
            for line in chf.readlines():
                time, letter = line.split()
                self._choreography.append((float(time), letter))

    def draw(self, proj):
        curr_time = playback_time(0)
        for (img, track, t) in reversed(self._fruits):
            x = width*(track+1)/4 - width/2
            y = (t - curr_time) * speed + hot_distance + 40
            draw_image(self._images[img], position=proj.vec((x, y)), scale=proj.size(1, y))

    def update(self, pressed):
        '''self._frame += 1
        if self._index < len(self._choreography):
            (frame, letter) = self._choreography[self._index]
            if frame <= self._frame:
                img = random.randint(0, len(self._images)-1)
                track = ['J', 'K', 'L'].index(letter)
                pos = (width*(track+1)/4 - width/2, height + 70)
                self._fruits.append((img, track, pos))
                self._index += 1

        for i in range(len(self._fruits)):
            (img, track, (x, y)) = self._fruits[i]
            y -= speed
            self._fruits[i] = (img, track, (x, y))

        okay_pressed = [False, False, False]
        to_remove = []
        for (i, (img, track, pos)) in enumerate(self._fruits):
            (x, y) = pos
            if pressed[track] and hot_distance-hot_radius <= y <= hot_distance+hot_radius:
                okay_pressed[track] = True
                to_remove.append(i)
            if y <= -50:
                to_remove.append(i)
                self._mistakes += 1
        for i in reversed(to_remove):
            self._fruits.pop(i)

        for (track, okay) in enumerate(okay_pressed):
            if pressed[track] and not okay:
                self._mistakes += 1'''

        curr_time = playback_time(0)
        
        if self._index < len(self._choreography):
            (time, letter) = self._choreography[self._index]
            if time - (height-hot_distance)/speed <= curr_time:
                img = random.randint(0, len(self._images)-1)
                track = ['J', 'K', 'L'].index(letter)
                self._fruits.append((img, track, time))
                self._index += 1

        okay_pressed = [False, False, False]
        to_remove = []
        for (i, (img, track, t)) in enumerate(self._fruits):
            y = (t - curr_time) * speed
            if pressed[track] and not okay_pressed[track] and -hot_radius <= y <= +hot_radius:
                okay_pressed[track] = True
                to_remove.append(i)
            if y <= -hot_distance:
                to_remove.append(i)
                self._mistakes += 1
        for i in reversed(to_remove):
            self._fruits.pop(i)

        for (track, okay) in enumerate(okay_pressed):
            if pressed[track] and not okay:
                self._mistakes += 1

    def mistakes(self):
        return self._mistakes

    def finished(self):
        return len(self._fruits) == 0 and self._index >= len(self._choreography)

# State variables.
stage = 'MENU'
countdown = -1
fruits = None

proj = Projector((width/2, 0), 0, height*3/2)

def draw_tracks(n, color=(1,1,1,1)):
    for i in range(1, n+1):
        column = width*i/(n+1) - width/2
        draw_polygon(
            proj.vec((column - track_width/2, 0)),
            proj.vec((column + track_width/2, 0)),
            proj.vec((column + track_width/2, height)),
            proj.vec((column - track_width/2, height)),
            color=color,
        )
    left = width*0.5/(n+1) - width/2
    right = width*(n+0.5)/(n+1) - width/2
    draw_polygon(
        proj.vec((left, hot_distance-hot_radius)),
        proj.vec((left, hot_distance+hot_radius)),
        proj.vec((right, hot_distance+hot_radius)),
        proj.vec((right, hot_distance-hot_radius)),
        color=color,
    )

def draw_fruits(fruits):
    for (typ, x, y) in fruits:
        draw_circle(proj.vec((x, y)), 40, color=(1, 0, 0, 1))

pasta = load_image('pasta.png')
cokolada = load_image('cokolada.png')
song = load_audio('cancan.wav', streaming=True)

open_window('Can Can Hero', width, height, fps=60)

try:
    should_quit = False
    while not should_quit:
        pressed = [False, False, False]

        for event in poll_events():
            if type(event) is CloseEvent:
                should_quit = True
            if type(event) is KeyDownEvent:
                if event.key == 'ENTER':
                    stage = 'GAME'
                    fruits = Fruits(['apple.png', 'pomaranc.png', 'kapusta.png'], 'choreography.txt')
                    play_audio(song)
                if event.key in ('J', 'K', 'L'):
                    pressed[['J', 'K', 'L'].index(event.key)] = True

        if stage == 'MENU':
            fill(0.3, 0.2, 0.3)
            draw_text(
                'Can Can Hero', 'Roboto', 72,
                position=(50, 300), color=(0.5, 0.9, 0.8, 1), bold=True,
            )
            draw_text(
                'Use J, K, L to play. Press [ENTER] to start/restart!', 'Roboto', 24,
                position=(50, 50), color=(0.7, 0.8, 0.7, 1),
            )
        elif stage == 'GAME':
            fruits.update(pressed)

            if fruits.finished():
                if fruits.mistakes() == 0:
                    stage = 'VICTORY'
                elif fruits.mistakes() > 500:
                    stage = 'SECRET'
                else:
                    stage = 'FAIL'

            fill(0.2, 0.1, 0.2)
            draw_tracks(3, color=(0.8, 0.9, 0.8, 1))
            fruits.draw(proj)
            draw_text(
                'BAD: {}'.format(fruits.mistakes()), 'Roboto', 24,
                position=(20, 550), color=(0.8, 0.9, 0.8, 1), italic=True,
            )
        elif stage == 'VICTORY':
            fill(0.3, 0.2, 0.3)
            draw_image(pasta, position=(400, 300))
            draw_text(
                'Press [ENTER] to play again.', 'Roboto', 24,
                position=(20, 20), color=(0.7, 0.8, 0.7, 1),
            )
        elif stage == 'SECRET':
            fill(0.3, 0.2, 0.3)
            draw_image(cokolada, position=(400, 300))
            draw_text(
                'Press [ENTER] to play again.', 'Roboto', 24,
                position=(20, 20), color=(0.7, 0.8, 0.7, 1),
            )
        elif stage == 'FAIL':
            fill(0.3, 0.2, 0.3)
            draw_text(
                'Better luck next time. Press [ENTER] to try again.'.format(fruits.mistakes()), 'Roboto', 24,
                position=(20, 20), color=(0.7, 0.8, 0.7, 1),
            )

        next_frame()

finally:
    close_window()
