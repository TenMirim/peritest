# -*- coding: utf-8 -*-
from easygame import *
import math
from random import randint

def vzdialenost(u, v):
    (ux, uy) = u
    (vx, vy) = v
    return math.hypot(ux-vx, uy-vy)

#Nacitanie obrazkov
jablko = load_image('apple.png')
pasta = load_image('pasta.png')
cokolada = load_image('cokolada.png')

#Konstanty
rychlost_hraca = 5
rychlost_veci = 4
polomer_ciela = 50
polomer_hraca = 50


#Stavove premenne hry
skore = 0
pozicia_hraca = (50,50)
pozicia_ciela = (randint(0,400),500)
hybem_vlavo = False
hybem_vpravo = False
vidim_cokoladu = False
koniec_hry = False

#Hlavny kod

open_window('Hra', 600, 400)
should_quit = False
while not should_quit:
    for event in poll_events():
        if type(event) is CloseEvent:
            should_quit = True
        if type(event) is KeyDownEvent:
            if event.key == 'LEFT':
                hybem_vlavo = True
            if event.key == 'RIGHT':
                hybem_vpravo = True
            if event.key == 'SPACE':
                vidim_cokoladu = True
        if type(event) is KeyUpEvent:
            if event.key == 'LEFT':
                hybem_vlavo = False
            if event.key == 'RIGHT':
                hybem_vpravo = False
            if event.key == 'SPACE':
                vidim_cokoladu = False
    #
    if skore < 10:
        (hrac_x, hrac_y) = pozicia_hraca
        if hybem_vlavo:
            hrac_x -= rychlost_hraca
        if hybem_vpravo:
            hrac_x += rychlost_hraca
        pozicia_hraca= (hrac_x, hrac_y)
        pozicia_ciela=(pozicia_ciela[0],pozicia_ciela[1]-rychlost_veci)
        if vzdialenost(pozicia_hraca, pozicia_ciela) <= polomer_ciela:
            skore = skore+1
            pozicia_ciela = (randint(0,400),500)
        if pozicia_ciela[1] < 0:
            koniec_hry = True
    #
    pozicia_hraca2 = (pozicia_hraca[0]+50,pozicia_hraca[1])
    fill(255,255,255)
    draw_image(jablko,pozicia_ciela,scale=0.8)
    draw_line(pozicia_hraca, (pozicia_hraca[0]+1,pozicia_hraca[1]), pozicia_hraca2, thickness = 10, color = (0,0,0,1))
    draw_text('Chyť 10 jabĺk.','Times New Roman', 10, position=(50,350), color=(0,0,0,1))
    if vidim_cokoladu:
        draw_image(cokolada, position =(300,200),scale=0.8)

    if skore>=10:
        draw_image(pasta, position=(300,200), scale=0.8)
        draw_text('YOU WIN!', 'Times New Roman', 32, position=(50,50), color=(0,0,1,1), bold = True)
    if koniec_hry:
        draw_text('Prehral si', 'Times New Roman', 32, position=(50,50), color=(0,0,1,1), bold = True)
    #

    next_frame()

close_window()

    
